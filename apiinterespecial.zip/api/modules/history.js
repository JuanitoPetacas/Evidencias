






// microservicio para crear el crud del historial delictivo
const express = require("express");
const history = express.Router();
const cnx = require("./bddata");

history.get("/history/listing", (req, res) => {
  let sql = "select * from history order by date";
  cnx.query(sql, (error, data) => {
    try {
      res.status(200).send(data);
    } catch {
      console.log("error");
      /*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
    }
  });
});

//consultar por id

history.get("/history/listing/:id", (req, res) => {
  let id = req.params.id;
  let sql = "select * from history  where id =  " + id;
  cnx.query(sql, (error, data) => {
    try {
      res.status(200).send(data);
    } catch {
      console.log("error");
      /*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
    }
  });
});
//ELIMINAR POR ID
history.delete("/history/deleteid/:id", (req, res) => {
  let id = req.params.id;
  let sql = "delete from history where id = " + id;
  cnx.query(sql, (error, data) => {
    try {
      res.status(200).send("Borradito");
    } catch {
      console.log("error");
      /*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
    }
  });
});

//insertt
history.post("/history/create", (req, res) => {
  let frmdata = req.body;

  cnx.query("INSERT INTO history SET ?", frmdata, (error, data) => {
    try {
      res.status(200).send("Insertado");
    } catch (error) {
      /*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
    }
  });
});
//editar
history.put("/history/update/:id", (req, res) => {
  let id = req.params.id; // parametros
  let frmdata = req.body;
  /*   console.log(frmdata)  */
  cnx.query(
    "UPDATE history SET ? WHERE id = ?",
    [frmdata, id],
    (error, data) => {
      try {
        res.status(200).send("Actualizacion exitosa");
      } catch {
        console.log("error");
        /*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
      }
    }
  );
});

module.exports = history;
