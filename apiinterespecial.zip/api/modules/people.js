// microservicio para crear el crud de las personas de la galaxia
const express = require("express");
const people = express.Router();
const cnx = require("./bddata");


people.get("/people/listing",(req,res)=>{
 let sql = "select * from people order by lastname ";
    cnx.query(sql,(error,data)=>{
 try{
res.status(200).send(data);
 }
 catch{
console.log("error");
/*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
 }
    })
})


//consultar por id

people.get("/people/listing/:id", (req, res) => {
    let id = req.params.id;
  let sql = "select * from people  where id =  " + id ;
  cnx.query(sql, (error, data) => {
    try {
      res.status(200).send(data);
    } catch {
      console.log("error");
      /*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
    }
  })
});
 //ELIMINAR POR ID
people.delete("/people/deleteid/:id", (req, res) => {
  let id = req.params.id;
  let sql = "delete from people where id = " + id;
  cnx.query(sql, (error, data) => {
    try {
      res.status(200).send("Borradito");
      alert("Usuario eliminado")
    } catch {
      console.log("error");
      /*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
    }
  })
});

//insertt
people.post("/people/create", (req, res) => {
  let frmdata = req.body;

  cnx.query("INSERT INTO people SET ?",frmdata,(error, data) => {
      try {
        res.status(200).send("Insertado");
     
      } catch (error) {
      
        /*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
      }
    }
  )
});
//editar
people.put("/people/update/:id", (req, res) => {
    let id = req.params.id; // parametros
  let frmdata = {
    name: req.body.name,
    lastname: req.body.lastname,
    nickname: req.body.nickname,
    email: req.body.email,
    type: req.body.type
  };
 /*   console.log(frmdata)  */
  cnx.query("UPDATE people SET ? WHERE id = ?", [frmdata, id], (error, data) => {
    try {
      res.status(200).send("Actualizacion exitosa");
     
    } catch {
      console.log("error");
      /*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
    }
  });
});

module.exports = people;
