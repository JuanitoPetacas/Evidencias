// microservicio para crear el crud de los usuarios
const express = require("express");
const users = express.Router();
const cnx = require("./bddata");

users.get("/users/listing", (req, res) => {
  let sql = "select * from users order by name";
  cnx.query(sql, (error, data) => {
    try {
      res.status(200).send(data);
    } catch {
      console.log("error");
      /*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
    }
  });
});

//consultar por id

users.get("/users/listing/:id", (req, res) => {
  let id = req.params.id;
  let sql = "select * from users  where id =  " + id;
  cnx.query(sql, (error, data) => {
    try {
      res.status(200).send(data);
    } catch {
      console.log("error");
      /*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
    }
  });
});
//ELIMINAR POR ID
users.delete("/users/deleteid/:id", (req, res) => {
  let id = req.params.id;
  let sql = "delete from users where id = " + id;
  cnx.query(sql, (error, data) => {
    try {
      res.status(200).send("Borradito");
    } catch {
      console.log("error");
      /*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
    }
  });
});

//insertt
users.post("/users/create", (req, res) => {
  let frmdata = req.body;

  cnx.query("INSERT INTO users SET ?", frmdata, (error, data) => {
    try {
      res.status(200).send("Insertado");
    } catch (error) {
      /*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
    }
  });
});
//editar
users.put("/users/update/:id", (req, res) => {
  let id = req.params.id; // parametros
  let frmdata = req.body;
  /*   console.log(frmdata)  */
  cnx.query(
    "UPDATE users SET ? WHERE id = ?",
    [frmdata, id],
    (error, data) => {
      try {
        res.status(200).send("Actualizacion exitosa");
      } catch {
        console.log("error");
        /*res.status(404).send({
    id: error.id,
    mensaje : error.menssage,
})*/
      }
    }
  );
});

module.exports = users;
